function onLoad(executionContext) {
    var formContext = executionContext.getFormContext();
    var status = formContext.getAttribute("statuscode").getValue();
    formContext.getControl("smp_reason").setVisible(status === 2);
    formContext.getControl("smp_reason").setDisabled(status !== 2);
    formContext.getAttribute("smp_reason").setRequiredLevel(status === 2 ? "required" : "none");
}